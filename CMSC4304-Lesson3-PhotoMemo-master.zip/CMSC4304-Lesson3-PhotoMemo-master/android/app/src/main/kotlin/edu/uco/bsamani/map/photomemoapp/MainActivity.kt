package edu.uco.bsamani.map.photomemoapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
